var console = {
    log: function () {},
    assert: function () {}
};